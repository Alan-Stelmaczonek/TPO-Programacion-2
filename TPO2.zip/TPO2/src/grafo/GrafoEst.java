package grafo;

public class GrafoEst<E> implements GrafoTDA<E> {
    private int[][] mAdy;
    private E[] etiqs;
    private int cantNodos;

    @SuppressWarnings("unchecked")
    public void inicializarGrafo() {
        mAdy = new int[100][100];
        etiqs = (E[])new Object[100];
        cantNodos = 0;
    }

    public void agregarVertice(E v) {
        etiqs[cantNodos] = v;
        for (int i = 0; i <= cantNodos; i++) {
            mAdy[cantNodos][i] = 0;
            mAdy[i][cantNodos] = 0;
        }
        cantNodos++;
    }

    public void eliminarVertice(E v) {
        int ind = vert2Indice(v);
        for (int k = 0; k < cantNodos; k++)
            mAdy[ind][k] = mAdy[cantNodos-1][k];
        for (int k = 0; k < cantNodos; k++)
            mAdy[k][ind] = mAdy[k][cantNodos-1];
        etiqs[ind] = etiqs[cantNodos-1];
        cantNodos--;
    }

    private int vert2Indice(E v) {
        int i = 0;
        while(i < this.cantNodos && !etiqs[i].equals(v))
            i++;
        return i;
    }

    public E[] vertices() {
        @SuppressWarnings("unchecked")
        E[] salida = (E[])new Object[cantNodos];
        for (int i = 0; i < cantNodos; i++) {
            salida[i] = etiqs[i];
        }
        return salida;
    }

    public void agregarArista(E v1, E v2, int peso) {
        int o = vert2Indice(v1);
        int d = vert2Indice(v2);
        mAdy[o][d] = peso;
    }

    public void eliminarArista(E v1, E v2) {
        int o = vert2Indice(v1);
        int d = vert2Indice(v2);
        mAdy[o][d] = 0;
    }

    public boolean existeArista(E v1, E v2) {
        int o = vert2Indice(v1);
        int d = vert2Indice(v2);
        return mAdy[o][d] != 0;
    }

    public int pesoArista(E v1, E v2) {
        int o = vert2Indice(v1);
        int d = vert2Indice(v2);
        return mAdy[o][d];
    }

    // EJERCICIO 2.1: Mayor costo de aristas salientes de un vertice
    public int mayorCostoSaliente(E v) {
        int ind = vert2Indice(v);
        int maxCosto = 0;

        for (int j = 0; j < cantNodos; j++) {
            if (mAdy[ind][j] > maxCosto) {
                maxCosto = mAdy[ind][j];
            }
        }

        return maxCosto;
    }

    // EJERCICIO 2.2: Predecesores de un vértice
    public E[] predecesores(E v) {
        int ind = vert2Indice(v);

        // Primero contar cuántos predecesores hay
        int count = 0;
        for (int i = 0; i < cantNodos; i++) {
            if (mAdy[i][ind] != 0) {
                count++;
            }
        }

        // Crear arreglo con el tamaño exacto
        @SuppressWarnings("unchecked")
        E[] resultado = (E[])new Object[count];

        // Llenar el arreglo con los predecesores
        int pos = 0;
        for (int i = 0; i < cantNodos; i++) {
            if (mAdy[i][ind] != 0) {
                resultado[pos] = etiqs[i];
                pos++;
            }
        }

        return resultado;
    }

    public int getCantNodos() {
        return cantNodos;
    }
}