package grafo;

public class Test {
    public static void main(String[] args) {
        System.out.println("=== EJERCICIO 2: GrafoEst (Matriz de Adyacencia) ===\n");
        testGrafoEstatico();

        System.out.println("\n=== EJERCICIO 3: GrafoDin (Listas de Adyacencia) ===\n");
        testGrafoDinamico();
    }

    public static void testGrafoEstatico() {
        GrafoEst<String> g = new GrafoEst<>();
        g.inicializarGrafo();

        // Agregar vértices
        g.agregarVertice("A");
        g.agregarVertice("B");
        g.agregarVertice("C");
        g.agregarVertice("D");

        // Agregar aristas con pesos
        g.agregarArista("A", "B", 5);
        g.agregarArista("A", "C", 10);
        g.agregarArista("A", "D", 3);
        g.agregarArista("B", "C", 8);
        g.agregarArista("C", "A", 7);

        System.out.println("Grafo creado con vértices: A, B, C, D");
        System.out.println("Aristas: A->B(5), A->C(10), A->D(3), B->C(8), C->A(7)");

        // EJERCICIO 2.1: Mayor costo saliente
        System.out.println("\n--- Ejercicio 2.1: Mayor costo de aristas salientes ---");
        System.out.println("Mayor costo saliente de A: " + g.mayorCostoSaliente("A"));
        System.out.println("Mayor costo saliente de B: " + g.mayorCostoSaliente("B"));
        System.out.println("Mayor costo saliente de C: " + g.mayorCostoSaliente("C"));
        System.out.println("Mayor costo saliente de D: " + g.mayorCostoSaliente("D"));

        // EJERCICIO 2.2: Predecesores
        System.out.println("\n--- Ejercicio 2.2: Predecesores ---");
        imprimirArreglo("Predecesores de A", g.predecesores("A"));
        imprimirArreglo("Predecesores de B", g.predecesores("B"));
        imprimirArreglo("Predecesores de C", g.predecesores("C"));
        imprimirArreglo("Predecesores de D", g.predecesores("D"));
    }

    public static void testGrafoDinamico() {
        GrafoDin<String> g = new GrafoDin<>();

        // Agregar vértices
        g.agregarVertice("A");
        g.agregarVertice("B");
        g.agregarVertice("C");
        g.agregarVertice("D");
        g.agregarVertice("E"); // E será aislado
        g.agregarVertice("F");

        // Agregar aristas
        g.agregarArista("A", "B", 1);
        g.agregarArista("B", "C", 1);
        g.agregarArista("A", "F", 1);
        g.agregarArista("F", "C", 1);
        g.agregarArista("D", "A", 1);

        System.out.println("Grafo creado con vértices: A, B, C, D, E, F");
        System.out.println("Aristas: A->B, B->C, A->F, F->C, D->A");
        System.out.println("(E es un vértice aislado)");

        // EJERCICIO 3.1: Vértices aislados
        System.out.println("\n--- Ejercicio 3.1: Vértices aislados ---");
        imprimirArreglo("Vértices aislados", g.verticesAislados());

        // EJERCICIO 3.2: Vértices puente
        System.out.println("\n--- Ejercicio 3.2: Vértices puente ---");
        imprimirArreglo("Puentes entre A y C", g.verticesPuente("A", "C"));
        imprimirArreglo("Puentes entre D y C", g.verticesPuente("D", "C"));
        imprimirArreglo("Puentes entre D y B", g.verticesPuente("D", "B"));
    }

    // Método corregido para imprimir arreglos de Object[]
    private static void imprimirArreglo(String titulo, Object[] arr) {
        System.out.print(titulo + ": [");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
            if (i < arr.length - 1) System.out.print(", ");
        }
        System.out.println("]");
    }
}