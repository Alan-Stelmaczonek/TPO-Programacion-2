package grafo;

public class GrafoDin<E> implements GrafoTDA<E> {
    private NodoVertice<E> origen;
    private int vertices;

    public GrafoDin() {
        origen = null;
        vertices = 0;
    }

    public void agregarVertice(E v) {
        NodoVertice<E> aux = new NodoVertice<E>();
        aux.setVertice(v);
        aux.setAristas(null);
        aux.setSigVertice(origen);
        origen = aux;
        vertices++;
    }

    public void eliminarVertice(E v) {
        if (origen.getVertice().equals(v))
            origen = origen.getSigVertice();
        NodoVertice<E> aux = origen;
        while (aux != null) {
            eliminarAristaNodo(aux, v);
            if (aux.getSigVertice() != null && aux.getSigVertice().getVertice().equals(v)) {
                aux.setSigVertice(aux.getSigVertice().getSigVertice());
                vertices--;
            }
            aux = aux.getSigVertice();
        }
    }

    private void eliminarAristaNodo(NodoVertice<E> nodo, E v) {
        NodoArista<E> aux = nodo.getAristas();
        if (aux != null) {
            if (aux.getVerticeDestino().getVertice().equals(v)) {
                nodo.setAristas(aux.getSigArista());
            }
            else {
                while (aux.getSigArista() != null &&
                        !aux.getSigArista().getVerticeDestino().getVertice().equals(v))
                    aux = aux.getSigArista();
                if (aux.getSigArista() != null) {
                    aux.setSigArista(aux.getSigArista().getSigArista());
                }
            }
        }
    }

    public E[] vertices() {
        @SuppressWarnings("unchecked")
        E[] salida = (E[])new Object[vertices];
        NodoVertice<E> aux = origen;
        int i = 0;
        while (aux != null) {
            salida[i] = aux.getVertice();
            i++;
            aux = aux.getSigVertice();
        }
        return salida;
    }

    public void agregarArista(E v1, E v2, int peso) {
        NodoVertice<E> n1 = vert2Nodo(v1);
        NodoVertice<E> n2 = vert2Nodo(v2);
        NodoArista<E> aux = new NodoArista<E>();
        aux.setPeso(peso);
        aux.setVerticeDestino(n2);
        aux.setSigArista(n1.getAristas());
        n1.setAristas(aux);
    }

    private NodoVertice<E> vert2Nodo(E v) {
        NodoVertice<E> aux = origen;
        while (aux != null && !aux.getVertice().equals(v))
            aux = aux.getSigVertice();
        return aux;
    }

    public void eliminarArista(E v1, E v2) {
        NodoVertice<E> n1 = vert2Nodo(v1);
        eliminarAristaNodo(n1, v2);
    }

    public boolean existeArista(E v1, E v2) {
        NodoVertice<E> n1 = vert2Nodo(v1);
        NodoArista<E> aux = n1.getAristas();
        while (aux != null && !aux.getVerticeDestino().getVertice().equals(v2)) {
            aux = aux.getSigArista();
        }
        return aux != null;
    }

    public int pesoArista(E v1, E v2) {
        NodoVertice<E> n1 = vert2Nodo(v1);
        NodoArista<E> aux = n1.getAristas();
        while (!aux.getVerticeDestino().getVertice().equals(v2))
            aux = aux.getSigArista();
        return aux.getPeso();
    }

    // EJERCICIO 3.1: Vértices aislados (sin aristas entrantes ni salientes)
    public E[] verticesAislados() {
        // Primero contar cuántos vértices aislados hay
        int count = 0;
        NodoVertice<E> aux = origen;

        while (aux != null) {
            if (esAislado(aux.getVertice())) {
                count++;
            }
            aux = aux.getSigVertice();
        }

        // Crear arreglo del tamaño exacto
        @SuppressWarnings("unchecked")
        E[] resultado = (E[])new Object[count];

        // Llenar el arreglo
        aux = origen;
        int pos = 0;
        while (aux != null) {
            if (esAislado(aux.getVertice())) {
                resultado[pos] = aux.getVertice();
                pos++;
            }
            aux = aux.getSigVertice();
        }

        return resultado;
    }

    // Metodo auxiliar: verifica si un vértice es aislado
    private boolean esAislado(E v) {
        // Verificar que no tenga aristas salientes
        NodoVertice<E> nodo = vert2Nodo(v);
        if (nodo.getAristas() != null) {
            return false; // Tiene aristas salientes
        }

        // Verificar que no tenga aristas entrantes
        NodoVertice<E> aux = origen;
        while (aux != null) {
            NodoArista<E> arista = aux.getAristas();
            while (arista != null) {
                if (arista.getVerticeDestino().getVertice().equals(v)) {
                    return false; // Hay una arista entrante
                }
                arista = arista.getSigArista();
            }
            aux = aux.getSigVertice();
        }

        return true; // No tiene aristas entrantes ni salientes
    }

    // EJERCICIO 3.2: Vértices puente entre v1 y v2
    public E[] verticesPuente(E v1, E v2) {
        // Primero contar cuántos puentes hay
        int count = 0;
        NodoVertice<E> aux = origen;

        while (aux != null) {
            E candidato = aux.getVertice();
            // Un vértice es puente si existe v1->candidato y candidato->v2
            if (!candidato.equals(v1) && !candidato.equals(v2) &&
                    existeArista(v1, candidato) && existeArista(candidato, v2)) {
                count++;
            }
            aux = aux.getSigVertice();
        }

        // Crear arreglo del tamaño exacto
        @SuppressWarnings("unchecked")
        E[] resultado = (E[])new Object[count];

        // Llenar el arreglo
        aux = origen;
        int pos = 0;
        while (aux != null) {
            E candidato = aux.getVertice();
            if (!candidato.equals(v1) && !candidato.equals(v2) &&
                    existeArista(v1, candidato) && existeArista(candidato, v2)) {
                resultado[pos] = candidato;
                pos++;
            }
            aux = aux.getSigVertice();
        }

        return resultado;
    }

    public int getVerticesCount() {
        return vertices;
    }
}