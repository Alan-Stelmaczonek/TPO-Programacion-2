import abb.*;
import grafo.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean continuar = true;

        while (continuar) {
            System.out.println("\n╔════════════════════════════════════════╗");
            System.out.println("║       MENÚ PRINCIPAL - TPO             ║");
            System.out.println("╚════════════════════════════════════════╝");
            System.out.println("1. Clase 8 - Ejercicio 7 (MultiDictionary con ABB)");
            System.out.println("2. Clase 9 - Ejercicio 6 (AVL Interactivo)");
            System.out.println("3. Clase 10 - Ejercicio 2 (Grafo Estático)");
            System.out.println("4. Clase 10 - Ejercicio 3 (Grafo Dinámico)");
            System.out.println("0. Salir");
            System.out.print("\nSeleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    ejercicioClase8();
                    break;
                case 2:
                    ejercicioClase9(scanner);
                    break;
                case 3:
                    ejercicioClase10_2();
                    break;
                case 4:
                    ejercicioClase10_3();
                    break;
                case 0:
                    continuar = false;
                    System.out.println("\n¡Hasta luego!");
                    break;
                default:
                    System.out.println("\nOpción inválida. Intente nuevamente.");
            }

            if (continuar && opcion != 0) {
                System.out.print("\nPresione Enter para continuar...");
                scanner.nextLine();
            }
        }

        scanner.close();
    }

    // ═══════════════════════════════════════════════════════════════
    // CLASE 8 - EJERCICIO 7: MultiDictionary con ABB
    // ═══════════════════════════════════════════════════════════════
    private static void ejercicioClase8() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("CLASE 8 - EJERCICIO 7: DICCIONARIO MÚLTIPLE CON ABB");
        System.out.println("=".repeat(60));

        MultiDictionary<String, Integer> dict = new MultiDictionary<>();

        System.out.println("\n--- Agregando elementos ---");
        dict.put("Matemáticas", 85);
        dict.put("Matemáticas", 92);
        dict.put("Matemáticas", 78);
        dict.put("Historia", 88);
        dict.put("Historia", 95);
        dict.put("Física", 90);
        dict.put("Física", 87);
        dict.put("Física", 93);

        System.out.println("Tamaño total del diccionario: " + dict.size() + " pares (clave, valor)");

        System.out.println("\n--- Consultando valores por clave ---");
        System.out.print("Notas de Matemáticas (ordenadas): ");
        for (Integer nota : dict.get("Matemáticas")) {
            System.out.print(nota + " ");
        }
        System.out.println();

        System.out.print("Notas de Historia (ordenadas): ");
        for (Integer nota : dict.get("Historia")) {
            System.out.print(nota + " ");
        }
        System.out.println();

        System.out.print("Notas de Física (ordenadas): ");
        for (Integer nota : dict.get("Física")) {
            System.out.print(nota + " ");
        }
        System.out.println();

        System.out.println("\n--- Eliminando un valor específico ---");
        dict.remove("Matemáticas", 78);
        System.out.print("Notas de Matemáticas después de eliminar 78: ");
        for (Integer nota : dict.get("Matemáticas")) {
            System.out.print(nota + " ");
        }
        System.out.println();

        System.out.println("\n--- Eliminando toda una clave ---");
        dict.remove("Historia");
        System.out.println("Tamaño después de eliminar Historia: " + dict.size());

        System.out.println("\n--- Listando todas las claves ---");
        System.out.println("Claves: " + dict.keys());

        System.out.println("\n--- Listando todas las entradas ---");
        for (Entry<String, Integer> e : dict.entries()) {
            System.out.println("  " + e);
        }

        System.out.println("\n✓ Ejercicio 7 completado exitosamente");
    }

    // ═══════════════════════════════════════════════════════════════
    // CLASE 9 - EJERCICIO 6: Programa interactivo con AVL
    // ═══════════════════════════════════════════════════════════════
    private static void ejercicioClase9(Scanner scanner) {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("CLASE 9 - EJERCICIO 6: AVL INTERACTIVO");
        System.out.println("=".repeat(60));

        // Usar referencia completa al paquete
        AVL.AVL<Double> avl = new AVL.AVL<>(new AVL.DefaultComparator<Double>());

        System.out.println("\nIngrese números (ingrese '.' para terminar):");
        System.out.print("> ");

        while (true) {
            String input = scanner.next();

            if (input.equals(".")) {
                break;
            }

            try {
                double numero = Double.parseDouble(input);
                avl.insert(numero);
                System.out.println("  ✓ " + numero + " insertado");
                System.out.print("> ");
            } catch (NumberFormatException e) {
                System.out.println("  ✗ Entrada inválida, intente nuevamente.");
                System.out.print("> ");
            }
        }

        if (avl.isEmpty()) {
            System.out.println("\n✗ No se ingresaron elementos.");
            return;
        }

        System.out.println("\n--- AVL generado por niveles ---");
        avl.imprimirPorNiveles();

        System.out.println("\n--- Elementos ordenados de menor a mayor ---");
        Object[] elementos = avl.getElementosOrdenados();
        System.out.print("[");
        for (int i = 0; i < elementos.length; i++) {
            System.out.print(elementos[i]);
            if (i < elementos.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");

        System.out.println("\n--- Información adicional ---");
        System.out.println("Altura del AVL: " + avl.height());
        System.out.println("Elemento mínimo: " + avl.min());

        System.out.println("\n✓ Ejercicio 6 completado exitosamente");
    }

    // ═══════════════════════════════════════════════════════════════
    // CLASE 10 - EJERCICIO 2: Grafo Estático (Matriz de Adyacencia)
    // ═══════════════════════════════════════════════════════════════
    private static void ejercicioClase10_2() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("CLASE 10 - EJERCICIO 2: GRAFO ESTÁTICO");
        System.out.println("=".repeat(60));

        GrafoEst<String> g = new GrafoEst<>();
        g.inicializarGrafo();

        System.out.println("\n--- Construyendo el grafo ---");
        g.agregarVertice("A");
        g.agregarVertice("B");
        g.agregarVertice("C");
        g.agregarVertice("D");
        g.agregarVertice("E");

        g.agregarArista("A", "B", 5);
        g.agregarArista("A", "C", 10);
        g.agregarArista("A", "D", 3);
        g.agregarArista("B", "C", 8);
        g.agregarArista("B", "E", 12);
        g.agregarArista("C", "A", 7);
        g.agregarArista("D", "E", 6);
        g.agregarArista("E", "C", 4);

        System.out.println("Vértices: A, B, C, D, E");
        System.out.println("Aristas:");
        System.out.println("  A → B (peso: 5)");
        System.out.println("  A → C (peso: 10)");
        System.out.println("  A → D (peso: 3)");
        System.out.println("  B → C (peso: 8)");
        System.out.println("  B → E (peso: 12)");
        System.out.println("  C → A (peso: 7)");
        System.out.println("  D → E (peso: 6)");
        System.out.println("  E → C (peso: 4)");

        System.out.println("\n--- EJERCICIO 2.1: Mayor costo de aristas salientes ---");
        String[] vertices = {"A", "B", "C", "D", "E"};
        for (String v : vertices) {
            int maxCosto = g.mayorCostoSaliente(v);
            System.out.println("  Vértice " + v + ": mayor costo saliente = " + maxCosto);
        }

        System.out.println("\n--- EJERCICIO 2.2: Predecesores de cada vértice ---");
        for (String v : vertices) {
            Object[] preds = g.predecesores(v);
            System.out.print("  Predecesores de " + v + ": [");
            for (int i = 0; i < preds.length; i++) {
                System.out.print(preds[i]);
                if (i < preds.length - 1) System.out.print(", ");
            }
            System.out.println("]");
        }

        System.out.println("\n✓ Ejercicio 2 completado exitosamente");
    }

    // ═══════════════════════════════════════════════════════════════
    // CLASE 10 - EJERCICIO 3: Grafo Dinámico (Listas de Adyacencia)
    // ═══════════════════════════════════════════════════════════════
    private static void ejercicioClase10_3() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("CLASE 10 - EJERCICIO 3: GRAFO DINÁMICO");
        System.out.println("=".repeat(60));

        GrafoDin<String> g = new GrafoDin<>();

        System.out.println("\n--- Construyendo el grafo ---");
        g.agregarVertice("A");
        g.agregarVertice("B");
        g.agregarVertice("C");
        g.agregarVertice("D");
        g.agregarVertice("E"); // E será aislado
        g.agregarVertice("F");
        g.agregarVertice("G");

        g.agregarArista("A", "B", 1);
        g.agregarArista("B", "C", 1);
        g.agregarArista("A", "F", 1);
        g.agregarArista("F", "C", 1);
        g.agregarArista("D", "A", 1);
        g.agregarArista("D", "G", 1);
        g.agregarArista("G", "B", 1);

        System.out.println("Vértices: A, B, C, D, E, F, G");
        System.out.println("Aristas:");
        System.out.println("  A → B");
        System.out.println("  B → C");
        System.out.println("  A → F");
        System.out.println("  F → C");
        System.out.println("  D → A");
        System.out.println("  D → G");
        System.out.println("  G → B");
        System.out.println("\nNota: E no tiene aristas (vértice aislado)");

        System.out.println("\n--- EJERCICIO 3.1: Vértices aislados ---");
        Object[] aislados = g.verticesAislados();
        System.out.print("Vértices aislados: [");
        for (int i = 0; i < aislados.length; i++) {
            System.out.print(aislados[i]);
            if (i < aislados.length - 1) System.out.print(", ");
        }
        System.out.println("]");
        System.out.println("(Un vértice es aislado si no tiene aristas entrantes ni salientes)");

        System.out.println("\n--- EJERCICIO 3.2: Vértices puente ---");

        System.out.print("Puentes entre A y C: [");
        Object[] puentesAC = g.verticesPuente("A", "C");
        for (int i = 0; i < puentesAC.length; i++) {
            System.out.print(puentesAC[i]);
            if (i < puentesAC.length - 1) System.out.print(", ");
        }
        System.out.println("]");
        System.out.println("  (B y F son puentes porque A→B→C y A→F→C)");

        System.out.print("\nPuentes entre D y C: [");
        Object[] puentesDC = g.verticesPuente("D", "C");
        for (int i = 0; i < puentesDC.length; i++) {
            System.out.print(puentesDC[i]);
            if (i < puentesDC.length - 1) System.out.print(", ");
        }
        System.out.println("]");
        System.out.println("  (A es puente porque D→A→... y hay camino A→C)");

        System.out.print("\nPuentes entre D y B: [");
        Object[] puentesDB = g.verticesPuente("D", "B");
        for (int i = 0; i < puentesDB.length; i++) {
            System.out.print(puentesDB[i]);
            if (i < puentesDB.length - 1) System.out.print(", ");
        }
        System.out.println("]");
        System.out.println("  (A y G son puentes: D→A→B y D→G→B)");

        System.out.println("\n✓ Ejercicio 3 completado exitosamente");
    }
}