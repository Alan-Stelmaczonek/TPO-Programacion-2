package abb;

import java.util.*;

public class MultiDictionary<K extends Comparable<K>, V extends Comparable<V>> implements Dictionary<K, V> {

    private ArbolBB<EntryNode<K, V>> tree;
    private int totalPairs = 0;

    private static class EntryNode<K extends Comparable<K>, V extends Comparable<V>>
            implements Comparable<EntryNode<K, V>> {
        K key;
        ArbolBB<V> values;

        EntryNode(K key) {
            this.key = key;
            this.values = new ArbolBB<>();
        }

        @Override
        public int compareTo(EntryNode<K, V> other) {
            return this.key.compareTo(other.key);
        }
    }

    public MultiDictionary() {
        tree = new ArbolBB<>();
    }

    @Override
    public int size() {
        return totalPairs;
    }

    @Override
    public boolean isEmpty() {
        return totalPairs == 0;
    }

    @Override
    public Iterable<V> get(K k) {
        EntryNode<K, V> found = findNode(k);
        if (found == null || found.values.isEmpty()) {
            return Collections.emptyList();
        }
        // IMPORTANTE: Devolver COPIA de los valores, no referencia interna
        return new ArrayList<>(found.values.inOrderList());
    }

    @Override
    public void put(K k, V v) {
        if (v == null) throw new IllegalArgumentException("value null");

        EntryNode<K, V> found = findNode(k);

        if (found == null) {
            // La clave no existe, crear nuevo nodo
            EntryNode<K, V> newNode = new EntryNode<>(k);
            newNode.values.insertar(v);
            tree.insertar(newNode);
            totalPairs++;
        } else {
            // La clave existe, agregar valor
            boolean inserted = found.values.insertarBool(v);
            if (inserted) totalPairs++;
        }
    }

    @Override
    public Iterable<V> remove(K k) {
        EntryNode<K, V> found = findNode(k);

        if (found == null) {
            return Collections.emptyList();
        }

        // IMPORTANTE: Copiar valores ANTES de eliminar
        List<V> vals = new ArrayList<>(found.values.inOrderList());
        totalPairs -= found.values.size();

        // Crear un nodo temporal solo para búsqueda
        EntryNode<K, V> searchNode = new EntryNode<>(k);
        tree.eliminar(searchNode);

        return vals;
    }

    @Override
    public V remove(K k, V v) {
        if (v == null) return null;

        EntryNode<K, V> found = findNode(k);
        if (found == null) return null;

        boolean removed = found.values.eliminarBool(v);
        if (!removed) return null;

        totalPairs--;

        // Si el ABB de valores quedó vacío, eliminar la clave
        if (found.values.isEmpty()) {
            EntryNode<K, V> searchNode = new EntryNode<>(k);
            tree.eliminar(searchNode);
        }

        return v;
    }

    @Override
    public List<K> keys() {
        List<K> result = new ArrayList<>();
        // Recorrer el árbol sin exponer EntryNode
        collectKeys(tree, result);
        return result;
    }

    @Override
    public List<Entry<K, V>> entries() {
        List<Entry<K, V>> result = new ArrayList<>();
        // Recorrer el árbol sin exponer EntryNode
        collectEntries(tree, result);
        return result;
    }

    // METODOS AUXILIARES PRIVADOS

    private EntryNode<K, V> findNode(K k) {
        List<EntryNode<K, V>> nodes = tree.inOrderList();
        for (EntryNode<K, V> node : nodes) {
            if (node.key.compareTo(k) == 0) {
                return node;
            }
        }
        return null;
    }


    private void collectKeys(ArbolBB<EntryNode<K, V>> tree, List<K> result) {
        List<EntryNode<K, V>> nodes = tree.inOrderList();
        for (EntryNode<K, V> node : nodes) {
            result.add(node.key);
        }
    }

    private void collectEntries(ArbolBB<EntryNode<K, V>> tree, List<Entry<K, V>> result) {
        List<EntryNode<K, V>> nodes = tree.inOrderList();
        for (EntryNode<K, V> node : nodes) {
            // Para cada clave, obtener COPIA de sus valores
            List<V> values = node.values.inOrderList();
            for (V value : values) {
                // Crear nuevos objetos Entry, no exponer estructura interna
                result.add(new Entry<>(node.key, value));
            }
        }
    }
}