package abb;
import java.util.Comparator;

public class Test {

    public static void main(String[] args) {

        System.out.println("=== EJERCICIO 1 y 2: Creación del ABB ===");
        ArbolBB<Integer> t = new ArbolBB<Integer>( new DefaultComparator<Integer>() );
        t.insertar2( 20 );
        t.insertar2( 16 );
        t.insertar2( 64 );
        t.insertar2( 6 );
        t.insertar2( 100 );
        t.insertar2( 3 );
        System.out.println("Árbol creado: " + t.toString());
        System.out.println();

        System.out.println("=== EJERCICIO 3: Recorridos en arreglos ===");
        Object[] pre = t.elementosPre();
        Object[] in = t.elementosIn();
        Object[] post = t.elementosPost();

        System.out.print("Pre-order:  ");
        for(Object i : pre) System.out.print(i + " ");
        System.out.println();

        System.out.print("In-order:   ");
        for(Object i : in) System.out.print(i + " ");
        System.out.println();

        System.out.print("Post-order: ");
        for(Object i : post) System.out.print(i + " ");
        System.out.println();
        System.out.println();

        System.out.println("=== EJERCICIO 4: MIN ===");
        System.out.println("Mínimo elemento: " + t.min());
        System.out.println();

        System.out.println("=== EJERCICIO 5: Imprimir por niveles ===");
        t.imprimirPorNiveles();
        System.out.println();

        System.out.println("=== EJERCICIO 6: Altura ===");
        System.out.println("Altura del árbol: " + t.height());
        System.out.println();

        System.out.println("=== EJERCICIO 7: Dictionary Múltiple ===");
        MultiDictionary<String, Integer> dict = new MultiDictionary<>();

        dict.put("A", 10);
        dict.put("A", 5);
        dict.put("A", 15);
        dict.put("B", 20);
        dict.put("B", 25);
        dict.put("C", 30);

        System.out.println("Tamaño total: " + dict.size());

        System.out.print("Valores para 'A': ");
        for(Integer v : dict.get("A")) System.out.print(v + " ");
        System.out.println();

        System.out.print("Valores para 'B': ");
        for(Integer v : dict.get("B")) System.out.print(v + " ");
        System.out.println();

        dict.remove("A", 5);
        System.out.print("Valores para 'A' después de eliminar 5: ");
        for(Integer v : dict.get("A")) System.out.print(v + " ");
        System.out.println();

        dict.remove("B");
        System.out.println("Tamaño después de eliminar toda 'B': " + dict.size());

        System.out.println("\nTodas las claves: " + dict.keys());

        System.out.println("\nTodas las entradas:");
        for(Entry<String, Integer> e : dict.entries()) {
            System.out.println("  " + e);
        }
    }
}