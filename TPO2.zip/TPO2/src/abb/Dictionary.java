package abb;

import java.util.List;

public interface Dictionary<K,V> {
    public int size();
    public boolean isEmpty();
    public Iterable<V> get(K k);
    public void put(K k, V v);
    public Iterable<V> remove(K k);
    public V remove(K k, V v);
    public List<K> keys();
    public List<Entry<K,V>> entries();
}