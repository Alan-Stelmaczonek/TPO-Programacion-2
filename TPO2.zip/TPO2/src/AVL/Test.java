package AVL;
import java.util.Comparator;
import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        System.out.println("=== EJERCICIOS 1 y 2: Creación y operaciones básicas del AVL ===");
        Comparator<Integer> d = new DefaultComparator<Integer>();
        AVL<Integer> tree = new AVL<Integer>(d);

        int[] values = {10, 20, 30, 40, 50, 25};
        System.out.println("Insertando valores:");
        for (int v : values) {
            System.out.println("Insert: " + v);
            tree.insert(v);
        }

        System.out.println("Recorrido in-order: " + tree.toString());

        System.out.println("\nEliminando valor 40:");
        tree.delete(40);
        System.out.println("Después de eliminar 40: " + tree.toString());

        System.out.println("\nInsertando valor 5:");
        tree.insert(5);
        System.out.println("Después de insertar 5: " + tree.toString());
        System.out.println();

        System.out.println("=== EJERCICIO 3: MIN ===");
        System.out.println("Elemento mínimo: " + tree.min());
        System.out.println();

        System.out.println("=== EJERCICIO 4: Imprimir por niveles ===");
        tree.imprimirPorNiveles();
        System.out.println();

        System.out.println("=== EJERCICIO 5: Altura del AVL ===");
        System.out.println("Altura: " + tree.height());
        System.out.println();

        System.out.println("=== EJERCICIO 6: Programa interactivo ===");
        ejercicio6();
    }

    // EJERCICIO 6: Programa interactivo
    public static void ejercicio6() {
        Scanner scanner = new Scanner(System.in);
        Comparator<Double> comp = new DefaultComparator<Double>();
        AVL<Double> avl = new AVL<Double>(comp);

        System.out.println("Ingrese números (ingrese '.' para terminar):");

        while (true) {
            String input = scanner.next();

            if (input.equals(".")) {
                break;
            }

            try {
                double numero = Double.parseDouble(input);
                avl.insert(numero);
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida, intente nuevamente.");
            }
        }

        if (avl.isEmpty()) {
            System.out.println("No se ingresaron elementos.");
            scanner.close();
            return;
        }

        System.out.println("\n--- AVL generado por niveles ---");
        avl.imprimirPorNiveles();

        System.out.println("\n--- Elementos ordenados de menor a mayor ---");
        Object[] elementos = avl.getElementosOrdenados();
        System.out.print("[");
        for (int i = 0; i < elementos.length; i++) {
            System.out.print(elementos[i]);
            if (i < elementos.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");

        scanner.close();
    }
}